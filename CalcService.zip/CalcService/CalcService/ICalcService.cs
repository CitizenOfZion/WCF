﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace CalcService
{
    [DataContract]
    public class ComplexNumber
    {
        [DataMember]
        public int x;
        [DataMember]
        public int y;
    }

    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "ICalcService" in both code and config file together.
    [ServiceContract]
    public interface ICalcService
    {
        [OperationContract(Name = "AddUsingDouble")]
        double Add(double n1, double n2);

        [OperationContract(Name = "AddUsingInt")]
        int Add(int p1, int p2);

        [OperationContract(Name = "AddUsingComplex")]
        ComplexNumber Add(ComplexNumber p1, ComplexNumber p2);


    }
}
