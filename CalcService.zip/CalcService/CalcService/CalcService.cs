﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace CalcService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "CalcService" in both code and config file together.
    public class CalcService : ICalcService
    {
        public double Add(double n1, double n2)
        {
            double result = n1 + n2;

            Console.Write("Received Add({0}, {1})", n1, n2);
            Console.WriteLine(" @ " + DateTime.Now.ToString());
            // Code added to write output to the console window.
            Console.WriteLine("Return: {0}", result);
            return result;
        }

        public int Add(int n1, int n2)
        {
            int result = n1 + n2;

            Console.Write("Received Add({0}, {1})", n1, n2);
            Console.WriteLine(" @ " + DateTime.Now.ToString());
            // Code added to write output to the console window.
            Console.WriteLine("Return: {0}", result);
            return result;
        }

        public ComplexNumber Add(ComplexNumber p1, ComplexNumber p2)
        {
            Console.Write("Received Add(({0}, {1}), ({2}, {3}))", p1.x, p1.y, p2.x, p2.y);
            Console.WriteLine(" @ " + DateTime.Now.ToString());
            ComplexNumber result = new ComplexNumber
            {
                x = p1.x + p2.x,
                y = p1.y + p2.y
            };
            Console.WriteLine("Return: ({0}, {1})", result.x, result.y);
            return result;
        }
    }
}
