﻿
namespace CalcServiceHost
{
    using System;
    using System.ServiceModel;

    class Program
    {
        static void Main()
        {
            using (ServiceHost host = new ServiceHost(typeof(CalcService.CalcService)))
            {
                host.Open();
                Console.WriteLine("Host Started @ " + DateTime.Now.ToString());
                Console.ReadLine();
            }
        }
    }
}
