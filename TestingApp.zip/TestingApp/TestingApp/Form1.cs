﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestingApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private CalcService.CalcServiceClient hsc = new CalcService.CalcServiceClient();

        private void Add_Click(object sender, EventArgs e)
        {
            SendMessageToService();            
        }

        private void SendMessageToService()
        {
            try
            {
                if (rbInBuilt.Checked)
                {
                    double result = hsc.AddUsingDouble(Double.Parse(D1.Text), Double.Parse(D2.Text));
                    Res.Text = result.ToString();
                }
                else if (rbUserDefined.Checked)
                {
                    CalcService.ComplexNumber p1 = new CalcService.ComplexNumber();
                    CalcService.ComplexNumber p2 = new CalcService.ComplexNumber();
                    
                    p1.x = int.Parse(P1X.Text);
                    p1.y = int.Parse(P1Y.Text);

                    p2.x = int.Parse(P2X.Text);
                    p2.y = int.Parse(P2Y.Text);

                    CalcService.ComplexNumber result = hsc.AddUsingComplex(p1, p2);
                    RX.Text = result.x.ToString();
                    RY.Text = result.y.ToString();
                }
                else
                {
                    MessageBox.Show("Select one of the parameters and enter the data");
                }
            }
            catch (FormatException fe)
            {
                MessageBox.Show(fe.ToString());
            }
            catch (ArgumentException ae)
            {
                MessageBox.Show(ae.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void rbInBuilt_CheckedChanged(object sender, EventArgs e)
        {
            EnableControlsAccordingly();
            
        }

        private void EnableControlsAccordingly()
        {
            if (rbInBuilt.Checked)
            {
                P1X.Enabled = false;
                P2X.Enabled = false;
                P2Y.Enabled = false;
                P1Y.Enabled = false;

                D1.Enabled = true;
                D2.Enabled = true;
            }
            else if (rbUserDefined.Checked)
            {
                D1.Enabled = false;
                D2.Enabled = false;

                P1X.Enabled = true;
                P2X.Enabled = true;
                P2Y.Enabled = true;
                P1Y.Enabled = true;
            }
        }

        private void rbUserDefined_CheckedChanged(object sender, EventArgs e)
        {
            EnableControlsAccordingly();
        }

        private void TestWRandNum_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            for (int i = 0; i < 10; i++)
            {
                rbUserDefined.Checked = false;
                rbInBuilt.Checked = true;
                EnableControlsAccordingly();
                double x = rnd.Next(1, 1000) / 100.0;
                double y = rnd.Next(1, 1000) / 100.0;
                D1.Text = x.ToString();
                D2.Text = y.ToString();
                Res.Text = "";
                Application.DoEvents();
                SendMessageToService();
                Thread.Sleep(3000);
                Application.DoEvents();

                rbInBuilt.Checked = false;
                rbUserDefined.Checked = true;
                EnableControlsAccordingly();
                int p1x = rnd.Next(1, 100);
                int p1y = rnd.Next(101, 200);
                int p2x = rnd.Next(201, 300);
                int p2y = rnd.Next(301, 400);
                P1X.Text = p1x.ToString();
                P1Y.Text = p1y.ToString();
                P2X.Text = p2x.ToString();
                P2Y.Text = p2y.ToString();
                RX.Text = "";
                RY.Text = "";
                
                Application.DoEvents();
                SendMessageToService();
                Thread.Sleep(3000);
                Application.DoEvents();
            }
        }
    }
}
