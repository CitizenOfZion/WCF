﻿namespace TestingApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Add = new System.Windows.Forms.Button();
            this.D1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.D2 = new System.Windows.Forms.TextBox();
            this.Res = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.P2X = new System.Windows.Forms.TextBox();
            this.P2Y = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.RY = new System.Windows.Forms.TextBox();
            this.RX = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.rbInBuilt = new System.Windows.Forms.RadioButton();
            this.rbUserDefined = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.TestWRandNum = new System.Windows.Forms.Button();
            this.P1X = new System.Windows.Forms.TextBox();
            this.P1Y = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(112, 239);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Result";
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(628, 184);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(75, 23);
            this.Add.TabIndex = 1;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // D1
            // 
            this.D1.Enabled = false;
            this.D1.Location = new System.Drawing.Point(186, 151);
            this.D1.Name = "D1";
            this.D1.Size = new System.Drawing.Size(100, 22);
            this.D1.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(112, 155);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Double1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(111, 184);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Double2";
            // 
            // D2
            // 
            this.D2.Enabled = false;
            this.D2.Location = new System.Drawing.Point(186, 184);
            this.D2.Name = "D2";
            this.D2.Size = new System.Drawing.Size(100, 22);
            this.D2.TabIndex = 5;
            // 
            // Res
            // 
            this.Res.Enabled = false;
            this.Res.Location = new System.Drawing.Point(186, 234);
            this.Res.Name = "Res";
            this.Res.Size = new System.Drawing.Size(100, 22);
            this.Res.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(341, 187);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 17);
            this.label4.TabIndex = 9;
            this.label4.Text = "Z2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(342, 158);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(25, 17);
            this.label5.TabIndex = 8;
            this.label5.Text = "Z1";
            // 
            // P2X
            // 
            this.P2X.Enabled = false;
            this.P2X.Location = new System.Drawing.Point(380, 184);
            this.P2X.Name = "P2X";
            this.P2X.Size = new System.Drawing.Size(60, 22);
            this.P2X.TabIndex = 11;
            // 
            // P2Y
            // 
            this.P2Y.Enabled = false;
            this.P2Y.Location = new System.Drawing.Point(476, 183);
            this.P2Y.Name = "P2Y";
            this.P2Y.Size = new System.Drawing.Size(60, 22);
            this.P2Y.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(473, 130);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 17);
            this.label6.TabIndex = 15;
            this.label6.Text = "Y (int)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(377, 130);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 17);
            this.label7.TabIndex = 14;
            this.label7.Text = "X (int)";
            // 
            // RY
            // 
            this.RY.Enabled = false;
            this.RY.Location = new System.Drawing.Point(476, 232);
            this.RY.Name = "RY";
            this.RY.Size = new System.Drawing.Size(60, 22);
            this.RY.TabIndex = 17;
            // 
            // RX
            // 
            this.RX.Enabled = false;
            this.RX.Location = new System.Drawing.Point(380, 233);
            this.RX.Name = "RX";
            this.RX.Size = new System.Drawing.Size(60, 22);
            this.RX.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(325, 237);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 17);
            this.label8.TabIndex = 18;
            this.label8.Text = "Result";
            // 
            // rbInBuilt
            // 
            this.rbInBuilt.AutoSize = true;
            this.rbInBuilt.Location = new System.Drawing.Point(183, 82);
            this.rbInBuilt.Name = "rbInBuilt";
            this.rbInBuilt.Size = new System.Drawing.Size(72, 21);
            this.rbInBuilt.TabIndex = 19;
            this.rbInBuilt.TabStop = true;
            this.rbInBuilt.Text = "In-Built";
            this.rbInBuilt.UseVisualStyleBackColor = true;
            this.rbInBuilt.CheckedChanged += new System.EventHandler(this.rbInBuilt_CheckedChanged);
            // 
            // rbUserDefined
            // 
            this.rbUserDefined.AutoSize = true;
            this.rbUserDefined.Location = new System.Drawing.Point(392, 81);
            this.rbUserDefined.Name = "rbUserDefined";
            this.rbUserDefined.Size = new System.Drawing.Size(113, 21);
            this.rbUserDefined.TabIndex = 20;
            this.rbUserDefined.TabStop = true;
            this.rbUserDefined.Text = "User-Defined";
            this.rbUserDefined.UseVisualStyleBackColor = true;
            this.rbUserDefined.CheckedChanged += new System.EventHandler(this.rbUserDefined_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(85, 53);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(604, 74);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select Parameter";
            // 
            // TestWRandNum
            // 
            this.TestWRandNum.Location = new System.Drawing.Point(223, 311);
            this.TestWRandNum.Name = "TestWRandNum";
            this.TestWRandNum.Size = new System.Drawing.Size(260, 34);
            this.TestWRandNum.TabIndex = 22;
            this.TestWRandNum.Text = "Test with Random Numbers";
            this.TestWRandNum.UseVisualStyleBackColor = true;
            this.TestWRandNum.Click += new System.EventHandler(this.TestWRandNum_Click);
            // 
            // P1X
            // 
            this.P1X.Enabled = false;
            this.P1X.Location = new System.Drawing.Point(380, 155);
            this.P1X.Name = "P1X";
            this.P1X.Size = new System.Drawing.Size(60, 22);
            this.P1X.TabIndex = 10;
            // 
            // P1Y
            // 
            this.P1Y.Enabled = false;
            this.P1Y.Location = new System.Drawing.Point(476, 155);
            this.P1Y.Name = "P1Y";
            this.P1Y.Size = new System.Drawing.Size(60, 22);
            this.P1Y.TabIndex = 12;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(444, 158);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(16, 17);
            this.label9.TabIndex = 23;
            this.label9.Text = "+";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(462, 157);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(11, 17);
            this.label11.TabIndex = 25;
            this.label11.Text = "i";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(462, 187);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(11, 17);
            this.label10.TabIndex = 27;
            this.label10.Text = "i";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(444, 188);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(16, 17);
            this.label12.TabIndex = 26;
            this.label12.Text = "+";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(462, 234);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(11, 17);
            this.label13.TabIndex = 29;
            this.label13.Text = "i";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(444, 235);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(16, 17);
            this.label14.TabIndex = 28;
            this.label14.Text = "+";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.TestWRandNum);
            this.Controls.Add(this.rbUserDefined);
            this.Controls.Add(this.rbInBuilt);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.RY);
            this.Controls.Add(this.RX);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.P2Y);
            this.Controls.Add(this.P1Y);
            this.Controls.Add(this.P2X);
            this.Controls.Add(this.P1X);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Res);
            this.Controls.Add(this.D2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.D1);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "ClientApp";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.TextBox D1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox D2;
        private System.Windows.Forms.TextBox Res;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox P2X;
        private System.Windows.Forms.TextBox P2Y;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox RY;
        private System.Windows.Forms.TextBox RX;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton rbInBuilt;
        private System.Windows.Forms.RadioButton rbUserDefined;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button TestWRandNum;
        private System.Windows.Forms.TextBox P1X;
        private System.Windows.Forms.TextBox P1Y;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
    }
}

